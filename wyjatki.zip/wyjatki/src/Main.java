public class Main {
    public static void main(String[] args) {
        RownanieKwadratowe rownanie = new RownanieKwadratowe(1, -5, 6);
        try {
            double[] rozwiazanie = rownanie.obliczRozwiazanie();
            System.out.println("x1 = " + rozwiazanie[0] + ", x2 = " + rozwiazanie[1]);
        } catch (DeltaUjemnaException e) {
            System.out.println("Delta ujemna!");
        }
    }
}